# Socket_Server_Csharp
socket server

## Directly use

1. clone
2. go to socket_server/bin/Debug
3. open socket_server.exe

## Use Visual Studio

1. clone
2. download Visual Studio
3. install C# components 
4. open socket_server.sln

### NOTE

- You can modify the code if you need, then you should bring your own server when demo
- If you counter bugs when using, contact me or TA in your group
